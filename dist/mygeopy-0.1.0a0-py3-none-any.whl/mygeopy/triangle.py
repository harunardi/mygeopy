import numpy as np

def hypot(a, b):
    return (a ** 2 + b ** 2) ** 0.5